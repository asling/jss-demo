const jss = require('jss');
const preset = require('jss-preset-default');
const BtnPrimary = require("./components/BtnPrimary"); 

console.log("BtnPrimary",BtnPrimary);

class Component{
    
    constructor(){
        this.padding = [10, 20, 10, 10];
    }

}

module.exports = Component;
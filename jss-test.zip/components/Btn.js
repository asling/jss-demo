class Btn{
    
    get _color(){
        return this.color = '#ffffff';
    }

}

module.exports = Btn;